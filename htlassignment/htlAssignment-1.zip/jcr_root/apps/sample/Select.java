package apps.sample;
import javax.script.Bindings;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.scripting.sightly.pojo.Use;


public class Select implements Use {

   private Iterable<Resource> page;

    @Override
    public void init(Bindings bindings) {

        ResourceResolver resourceResolver = (ResourceResolver)bindings.get("resolver");

//        page = String.valueOf((Resource) bindings.get("resource"));
        page = resourceResolver.getResource("/content/my-options").getChildren();
        // page = String.valueOf(resourceResolver);
    }

    public Iterable<Resource> getPage() {
        return this.page;
    }

}