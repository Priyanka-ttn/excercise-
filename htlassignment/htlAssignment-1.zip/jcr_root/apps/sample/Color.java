package apps.sample;
import javax.script.Bindings;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.scripting.sightly.pojo.Use;
import org.apache.sling.api.resource.ValueMap;


public class Color implements Use {

    private ValueMap page;
    private ValueMap page2;
    private ValueMap page3;

    @Override
    public void init(Bindings bindings) {

        ResourceResolver resourceResolver = (ResourceResolver)bindings.get("resolver");

//        page = String.valueOf((Resource) bindings.get("resource"));
        page = resourceResolver.getResource("/content/my-options/opt1").getValueMap();
         page2 = resourceResolver.getResource("/content/my-options/opt2").getValueMap();
          page3 = resourceResolver.getResource("/content/my-options/opt3").getValueMap();
        // page = String.valueOf(resourceResolver);
    }

    public ValueMap getPage() {
        return this.page;
    }
    
       public ValueMap getPage2() {
        return this.page2;
    }
    
    public ValueMap getPage3() {
        return this.page3;
    }

}